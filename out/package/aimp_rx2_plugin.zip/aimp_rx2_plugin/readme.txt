This plugin uses the Rex Shared Library.dll provided by Propellerhead Software.

Please note:

The 32-bit version of the Rex Shared Library is no longer maintained. The last available 32-bit release is v1.6.

All future updates to the library are released only for the 64-bit version.

Because of this, it is strongly recommended to use the 64-bit version of the RX2 Plugin for best compatibility and stability.